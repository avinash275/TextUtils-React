import aj ,{b,c,d} from './module2.mjs'
console.log(aj+b+c+d)