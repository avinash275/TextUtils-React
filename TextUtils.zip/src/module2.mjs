const a="Avinash"
const b="Vishal"
const c="Nikita"
const d="Anil"
export default a;
export {b,c,d}