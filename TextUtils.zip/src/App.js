import "./App.css";
import About from "./components/About";
import Navbar from "./components/Navbar";
import TextForm from "./components/TextForm";
import Contact from "./components/Contact";

import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";

function App() {
  return (
    <>
      <Router>
        <Navbar title="TextUtils" About="About Us" Contact='Contact Us' />
        <div>
          
          <Routes>
            <Route path="/" element={<TextForm heading="Enter a text to Analyze" />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact/>}/>
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
